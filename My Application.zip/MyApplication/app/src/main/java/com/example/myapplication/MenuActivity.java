package com.example.myapplication;

public class MenuActivity {
}
