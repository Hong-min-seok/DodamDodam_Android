package com.example.myapplication;

public class LogingActivity {
}
